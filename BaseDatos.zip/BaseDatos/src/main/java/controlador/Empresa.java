package controlador;

public class Empresa {

}
