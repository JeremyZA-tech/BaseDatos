package vista;

public class MenuDepartamento {
	


}
