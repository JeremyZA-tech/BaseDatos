package vista;

public class MenuEmpleado {

}
